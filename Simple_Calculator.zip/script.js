function val(result){
  form.disp.value=form.disp.value + result;
}
function calc(){
  if(form.disp.value==""){
    alert("Please enter numbers")
  }else{
    form.disp.value= eval(form.disp.value);
  }
}
function clr(){
   form.disp.value= "" 
}
